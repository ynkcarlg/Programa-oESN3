package com.example.universidadeESN3.controller;

public class ProfessorController {
}
